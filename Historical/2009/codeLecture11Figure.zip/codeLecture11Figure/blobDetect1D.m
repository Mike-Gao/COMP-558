%  Code for making a figure showing a scale space of a blob filtered with
%  a normalized second derivative of a Gaussian. 
%
%  Make an image of a blob.

N = 300;      % size of image

x0 = 170;     % left and right coordinates blo
x1 = 186;

I = zeros(1,N);
I(x0:x1) = 100;   % arbitrary amplitude (not important)

%  define the sigma values for scale space.  The sigma values
%  are sampled logarithmically, not linearly.

minLog2Sigma = -1;  
maxLog2Sigma = 5;
stepLog2Sigma = 0.1;
sigmas = power(2, minLog2Sigma : stepLog2Sigma : maxLog2Sigma);
tmp = size(sigmas);
numSigmas = tmp(2);

%  build the scale space

Ixx = zeros(numSigmas,N);
Iblur = zeros(numSigmas,N);
for sigmaCt = 1:numSigmas
    
    sigInner = sigmas(sigmaCt); 
    Iblur(sigmaCt,:) = blur1D(I,sigInner);

%  Use "conv2" rather than "conv" because the former has an optional
%  'same' parameter which prunes off parts of meaningless boundary,
%  always returns the same width images Ix and Ixx.  This is convenient
%  for stitching the Ixx vectors into a scale space image of that
%  same width.
%  (Recall that prune off values near the boundary is fine since 
%  convolution has to do arbitrary things at the image boundary and
%  so the values are meaningless junk there.)

   Ix = sigInner*conv2( Iblur(sigmaCt,:) , [1, 0, -1], 'same');
   Ixx(sigmaCt,:) = sigInner * conv2( Ix , [1, 0, -1], 'same');

end

%  The blur1D function calls a makeGaussian function, which creates
%  a Gaussian is of width 6 sigma.   
%  We have removed some of the boundary junk above, but there is 
%  more.  We only plot the image in non-junk regions. 

junkIwidth = 3*sigmas(numSigmas);

close all

imagesc(junkIwidth:N-junkIwidth,minLog2Sigma : stepLog2Sigma : maxLog2Sigma,...
    Iblur(:,junkIwidth:N-junkIwidth));
ylabel('log2(sigma)','fontsize',14)
colormap gray
title('Gaussian scale space','fontsize',14);
xlabel('x');
print -deps blobGaussian

figure
imagesc(junkIwidth:N-junkIwidth,minLog2Sigma : stepLog2Sigma : maxLog2Sigma,...
      Ixx(:,junkIwidth:N-junkIwidth) );
ylabel('log2(sigma)','fontsize',14)
xlabel('x','fontsize',14);
colormap gray
title('normalized 2nd deriv Gaussian scale space','fontsize',14);
print -deps blob2ndDerivGauss