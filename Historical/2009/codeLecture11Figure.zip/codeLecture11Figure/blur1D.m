function blurredI = blur1D(I,sig)
%
%  Convolves an input image with a 1D Gaussian of
%  standard deviation sig.  (The length of the Gaussian
%  vector goes up to 3 times the standard deviation.)

N = round(6*sig);
if (mod(N,2) == 0)
    N=N+1;
end
g = makeGaussian(N,sig)';   % N is odd

%  conv with an filter of length N1 >= N2
%  return trustworthy values of N1 - N2 + 1
%
%  makeGaussian returns vector of length 6*sig 
%  
blurredI =  conv2( double(I), g, 'same');

