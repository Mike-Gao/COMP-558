function g = makeGaussian(N,sig)
%
%  returns a N vector  Gaussian with standard deviation sig 
%

g = zeros(N,1);
g(1:N) = 1/sqrt(2 * pi) / sig * ...
             exp( - power( (1:N) - ceil(N/2),2) / (2 * sig*sig));



