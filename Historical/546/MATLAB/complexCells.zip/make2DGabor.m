function [cosGabor sinGabor] = make2DGabor(N,k0,k1)
%
% Returns an NxN 2D cosine and sine Gabor with standard 
% deviation center frequency (k0,k1) cycles per N samples.   
% First argument is horizontal (x), second is vertical (y).
% 
% The (k0, k1) do not need to be integers.
%
%  The sigma of the Gaussian is chosen to be one quarter cycle of the
%  underlying sinusoidal wave.  That is, 4*sigma is one cycle.   
%
%  Author:  Michael Langer

k      = sqrt(k0*k0 + k1*k1);
sigmaX = N/k/2;

%  In case you are curious...
%  the Fourier transform of a Gaussian with standard deviation sigma
%  is a Gaussian with standard deviation N/(2*pi*sigma).
%
%   sigmaK = N / (2*pi * sigmaX);

%  The bandwidth of a filter is sometimes defined by half height.  
%  However, when the filter has a Gaussian shape in the frequency domain  
%  one often defines the bandwidth by the standard deviation.  
%  Say  k =sqrt(k0*k0 + k1*k1)).   Then the "octavebandwidth"
%  (which is just the log2 of the bandwidth) is:
%
%  display(['octavebandwidth = ',...
%    num2str(log2( (k + sigmaK) / (k - sigmaK) )),' octave']);

% Don't round off frequencies
%
% if  ((round(k0) ~= k0) || (round(k1) ~= k1))
%    display('WARNING:   frequencies are not integers.. rounding');
%    k0 = round(k0);
%    k1 = round(k1);
% end

%cos2D = fftshift( make2Dcosine(N,k0,k1) );
%sin2D = fftshift( make2Dsine(N,k0,k1) );

cos2D = make2Dcosine(N,k0,k1) ;
sin2D = make2Dsine(N,k0,k1) ;

%  Define the Gabor to be centered at (N/2+1).   

shiftx = ((1:N) - (N/2 + 1));
Gaussian = 1/(sqrt(2*pi)*sigmaX) * ...
    exp(- shiftx.*shiftx/ (2 * sigmaX*sigmaX) );
Gaussian2D = Gaussian' * Gaussian;

cosGabor = Gaussian2D .* cos2D;
sinGabor = Gaussian2D .* sin2D;