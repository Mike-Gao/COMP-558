function I = make2Dcosine(N,KX,KY)
%  I = make2Dcosine(N,KX,KY);
%
%  Do NOT require that KX and KY are integers.  
%  It assumes the origin is (N/2+1, N/2+1).
%
%  This program displays a 2D cosine wave cos( 2pi/N (KX x + KY y)).
%  where x,y can be float or double.

% cos( KX * X + KY * Y) =  cos( KX * X) * cos( KY * Y) - ...
%                          sin( KX * X) * sin( KY * Y);
 
%  X is horizontal,  Y is vertical

%  Puts origin at (1,1)
%  I = cos(2*pi/N* (KY * (0:N-1)')) * cos(2*pi/N* KX * (0:N-1))  - ...
%    sin(2*pi/N* (KY * (0:N-1)')) * sin(2*pi/N* KX * (0:N-1)) ;

%  Puts origin at (N/2+1, N/2+1)
I = cos(2*pi/N* (KY * (-N/2:N/2-1)')) * cos(2*pi/N* KX * (-N/2:N/2-1))  - ...
    sin(2*pi/N* (KY * (-N/2:N/2-1)')) * sin(2*pi/N* KX * (-N/2:N/2-1)) ;