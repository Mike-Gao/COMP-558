function gaussian = makeGaussian(sig)
%
%  returns a 1xN vector  Gaussian with standard deviation sig.

if (sig < .3)
    
    %  for small sig, we can approximate the gaussian using 
    %  x = (-1, 0, 1) only.   The density below gives a 
    %  variance of sig*sig. 
    gaussian = [sig*sig/2   (1 - sig*sig)  sig*sig/2]';
else
  N = round(9*max(sig,1));
  gaussian = zeros(N,1);
  gaussian(1:N) = exp( - power( (1:N) - N/2 - .5,2) / (2 * sig*sig));
  gaussian = gaussian / sum(gaussian);
end

