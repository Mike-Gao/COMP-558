%   function remapImage.m
%
%   Take an image which may have positive and negative values and
%   remap the values so that 0 maps to 127 and the range is within
%   0 to 255.

function vNormalized = remapImage(image)
vNormalized = uint8(127 + 128*image/max(abs(image(:))) );